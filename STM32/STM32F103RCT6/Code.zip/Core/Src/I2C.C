#include "main.h"

void Delay_10us(void);
/****************************/

static void Delay_10us(void)
{
	uint8_t i;
	for (i = 0; i < 155; i++);
}

//================================================

void IIC_Start(void)
{   
	IIC_SDA1();
	Delay_10us();		
	IIC_SCL1();
	Delay_10us();
	IIC_SDA0();
	Delay_10us();		
	IIC_SCL0();
	Delay_10us();	
}
//================================================
void IIC_Stop(void)
{
	IIC_SCL0();
	Delay_10us();
	IIC_SDA0();
	Delay_10us();
	IIC_SCL1();
	Delay_10us();
	IIC_SDA1();
	Delay_10us();	
}
//================================================
void IIC_ACK(void)
{
	IIC_SDA0();
	Delay_10us();
	
	IIC_SCL1();
	Delay_10us();
	
	IIC_SCL0();
	Delay_10us();
}
//================================================
void IIC_NoAck(void)
{
	IIC_SDA1();
	Delay_10us();
	
	IIC_SCL1();
	Delay_10us();
	
	IIC_SCL0();
	Delay_10us();
}
//================================================
uint8_t IIC_ReadByte(void)
{
	uint8_t ucValue;
	uint8_t ucIndex;
	SDA_IN() 
	ucValue=0;
	for ( ucIndex = 0; ucIndex < 8; ucIndex++ )
	{		
	    ucValue <<= 1;
			IIC_SCL0();
			Delay_10us();
		  IIC_SCL1();
			Delay_10us();
                		
			if(IIC_SDA){
					ucValue |= 1;
			}
			Delay_10us();
			IIC_SCL0();
			Delay_10us();
	}
	SDA_OUT() 
	return ucValue;
}

//================================================
void IIC_WriteByte( uint8_t ucData )
{
	uint8_t i;
	for( i = 0; i < 8; i++ )
	{
		IIC_SCL0();
  	Delay_10us();
		if((ucData & 0x80) == 0x80)
		{ 
			IIC_SDA1();
		}
		else
		{
			IIC_SDA0();
			Delay_10us();
		}
		Delay_10us();
		IIC_SCL1();
  	Delay_10us();
		ucData <<= 1;
		IIC_SCL0();
		Delay_10us();
	}
	SDA_IN() 
	Delay_10us();
	IIC_SCL0();
	Delay_10us();
	IIC_SCL1();
	Delay_10us();
	IIC_SCL0();
	Delay_10us();   
  SDA_OUT()
} 
