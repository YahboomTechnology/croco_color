#ifndef __I2C_H
#define __I2C_H

#include "main.h"

void IIC_Start(void);
void IIC_Stop(void);
void IIC_ACK(void);
void IIC_NoAck(void);
uint8_t  IIC_ReadByte(void);
void IIC_WriteByte( uint8_t ucData );


#endif
